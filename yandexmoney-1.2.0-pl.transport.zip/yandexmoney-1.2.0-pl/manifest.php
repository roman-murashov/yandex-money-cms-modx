<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Лицензионный договор.

Любое использование Вами программы означает полное и безоговорочное принятие Вами условий лицензионного договора, размещенного по адресу https://money.yandex.ru/doc.xml?id=527132 (далее – «Лицензионный договор»). Если Вы не принимаете условия Лицензионного договора в полном объёме, Вы не имеете права использовать программу в каких-либо целях.',
    'readme' => 'Инструкция для работы с модулем.

После установки модуля необходимо:
1. В чанке формы заказа, в списке способов оплаты указать [[!YandexMoney?&action=`showMethods` ]]
Т.е., например, в чанке shopOrderForm будет:
```
<select name="payment" style="width:200px;">
	<option value="При получении" [[!+fi.payment:FormItIsSelected=`При получении`]]>При получении</option>
        [[!YandexMoney? &action=`showMethods` ]]
</select>
```
2. В чанке страницы заказа, в список хуков FormIt добавить YandexMoneyHook
Т.е., например, чанк orderform_page
```
[[!FormIt?
&hooks=`spam,shk_fihook,YandexMoneyHook,email,FormItAutoResponder,redirect`
&submitVar=`order`
&emailTpl=`shopOrderReport`
&fiarTpl=`shopOrderReport`
&emailSubject=`В интернет-магазине "[[++site_name]]" сделан новый заказ`
&fiarSubject=`Вы сделали заказ в интернет-магазине "[[++site_name]]"`
&emailTo=`[[++emailsender]]`
&redirectTo=`25`
&validate=`address:required,fullname:required,email:email:required,phone:required`
&errTpl=`<br /><span class="error">[[+error]]</span>`
]]
```
3. Создать 2 страницы: для успешно завершенного платежа и неуспешно завершенного. Указать их ID документа в параметрах сниппета YandexMoney. 

4. Указать настройки магазина в параметрах сниппета YandexMoney.
',
    'changelog' => '### 25.09.2015
* Добавлены платежные методы QW,QP

### 11.06.2015
* Добавлены платежные методы PB,MA

### 17.05.2015
* Добавлена инструкция в установочный пакет
* Пересоздание установочного пакета

### 15.05.2015
* Создан файл изменений
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '2b1dfaeaa9c2e523ef66fc9da69ee98a',
      'native_key' => 'yandexmoney',
      'filename' => 'modNamespace/d3cf54722923b688731c67e46a31062f.vehicle',
      'namespace' => 'yandexmoney',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'c03fc764c33f6f3f363cbe906544fc7e',
      'native_key' => 1,
      'filename' => 'modCategory/3ce3a19841e273d959f720c5d784a3e6.vehicle',
      'namespace' => 'yandexmoney',
    ),
  ),
);