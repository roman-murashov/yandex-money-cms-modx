<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Лицензионный договор.

Любое использование Вами программы означает полное и безоговорочное принятие Вами условий лицензионного договора,
размещенного по адресу https://money.yandex.ru/doc.xml?id=527132 (далее – «Лицензионный договор»). Если Вы не
принимаете условия Лицензионного договора в полном объёме, Вы не имеете права использовать программу в
каких-либо целях.',
    'readme' => '--------------------
Extra: YandexMoney
--------------------
Version: 1.4

Инструкция для работы с модулем.

После установки модуля необходимо:
1. В чанке формы заказа, в списке способов оплаты указать [[!YandexMoney?&action=`showMethods`]]
Т.е., например, в чанке shopOrderForm будет:
```
<select name="payment" style="width:200px;">
	<option value="При получении" [[!+fi.payment:FormItIsSelected=`При получении`]]>При получении</option>
        [[!YandexMoney? &action=`showMethods` ]]
</select>
```
2. В чанке страницы заказа, в список хуков FormIt добавить YandexMoneyHook
Т.е., например, чанк orderform_page
```
[[!FormIt?
&hooks=`spam,shk_fihook,YandexMoneyHook,email,FormItAutoResponder,redirect`
&submitVar=`order`
&emailTpl=`shopOrderReport`
&fiarTpl=`shopOrderReport`
&emailSubject=`В интернет-магазине "[[++site_name]]" сделан новый заказ`
&fiarSubject=`Вы сделали заказ в интернет-магазине "[[++site_name]]"`
&emailTo=`[[++emailsender]]`
&redirectTo=`25`
&validate=`address:required,fullname:required,email:email:required,phone:required`
&errTpl=`<br /><span class="error">[[+error]]</span>`
]]
```
3. Создать 2 страницы: для успешно завершенного платежа и неуспешно завершенного. Указать их ID документа в параметрах сниппета YandexMoney.

4. Указать настройки магазина в параметрах сниппета YandexMoney.
',
    'changelog' => 'Changelog file for YandexMoney component.
 
YandexMoney 1.4.1
====================================

### 16.08.2017
* Добавлен функционал работы с Яндекс.Платёжкой

### 05.06.2017
* Добавлена поддержка отправки данных чека по 54-ФЗ

### 25.03.2016
* Добавлен выбор режима оплаты для Яндекс.Кассы

### 25.09.2015
* Добавлены платежные методы QW,QP
* Добавлен новый параметр в платежную форму для p2p

### 11.06.2015
* Добавлены платежные методы PB,MA

### 17.05.2015
* Добавлена инструкция в установочный пакет
* Пересоздание установочного пакета

### 15.05.2015
* Создан файл изменений

',
    'setup-options' => 'yandexmoney-1.4.1-1/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5199d91ee35999652b4cb9924cf106fb',
      'native_key' => 'yandexmoney',
      'filename' => 'modNamespace/d0377dae6231d366e82bf03e9abe752b.vehicle',
      'namespace' => 'yandexmoney',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '4cfe8d430e58240b298bbb65c1db49cf',
      'native_key' => 1,
      'filename' => 'modCategory/eecda1da983c9a67d8470fe703db9246.vehicle',
      'namespace' => 'yandexmoney',
    ),
  ),
);